import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import HomeScreen from './screens/HomeScreen';
import ListScreen from './screens/ListScreen';
import HistoryScreen from './screens/HistoryScreen';
import SettingsScreen from './screens/SettingsScreen';
import { StorageService } from './services/StorageService';
import { NotificationService } from './services/NotificationService';
import './App.css';

function App() {
  const [lists, setLists] = useState([]);
  const [history, setHistory] = useState([]);
  const [settings, setSettings] = useState({ weeklyNotifications: true });

  useEffect(() => {
    // Load data from localStorage on app start
    const savedLists = StorageService.getLists();
    const savedHistory = StorageService.getHistory();
    const savedSettings = StorageService.getSettings();
    
    setLists(savedLists);
    setHistory(savedHistory);
    setSettings(savedSettings);

    // Initialize notifications
    NotificationService.init(savedSettings);
  }, []);

  const createList = (name) => {
    const newList = {
      id: Date.now().toString(),
      name,
      items: [],
      createdAt: new Date().toISOString()
    };
    
    const updatedLists = [...lists, newList];
    setLists(updatedLists);
    StorageService.saveLists(updatedLists);
    return newList.id;
  };

  const deleteList = (listId) => {
    const listToDelete = lists.find(list => list.id === listId);
    if (listToDelete) {
      // Move to history
      const updatedHistory = [...history, { ...listToDelete, deletedAt: new Date().toISOString() }];
      setHistory(updatedHistory);
      StorageService.saveHistory(updatedHistory);
    }

    const updatedLists = lists.filter(list => list.id !== listId);
    setLists(updatedLists);
    StorageService.saveLists(updatedLists);
  };

  const updateList = (listId, updatedList) => {
    const updatedLists = lists.map(list => 
      list.id === listId ? { ...list, ...updatedList } : list
    );
    setLists(updatedLists);
    StorageService.saveLists(updatedLists);
  };

  const duplicateFromHistory = (historyItem) => {
    const newList = {
      ...historyItem,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      items: historyItem.items.map(item => ({ ...item, purchased: false }))
    };
    delete newList.deletedAt;

    const updatedLists = [...lists, newList];
    setLists(updatedLists);
    StorageService.saveLists(updatedLists);
    return newList.id;
  };

  const updateSettings = (newSettings) => {
    setSettings(newSettings);
    StorageService.saveSettings(newSettings);
    NotificationService.updateSettings(newSettings);
  };

  return (
    <Router>
      <div className="app">
        <AnimatePresence mode="wait">
          <Routes>
            <Route 
              path="/" 
              element={
                <HomeScreen 
                  lists={lists} 
                  onCreateList={createList} 
                  onDeleteList={deleteList} 
                />
              } 
            />
            <Route 
              path="/list/:id" 
              element={
                <ListScreen 
                  lists={lists} 
                  onUpdateList={updateList} 
                />
              } 
            />
            <Route 
              path="/history" 
              element={
                <HistoryScreen 
                  history={history} 
                  onDuplicate={duplicateFromHistory} 
                />
              } 
            />
            <Route 
              path="/settings" 
              element={
                <SettingsScreen 
                  settings={settings} 
                  onUpdateSettings={updateSettings} 
                />
              } 
            />
          </Routes>
        </AnimatePresence>
      </div>
    </Router>
  );
}

export default App;