import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const { FiHome, FiClock, FiSettings } = FiIcons;

const BottomNavigation = ({ currentScreen }) => {
  const navigate = useNavigate();

  const navItems = [
    { id: 'home', icon: FiHome, label: 'Home', path: '/' },
    { id: 'history', icon: FiClock, label: 'History', path: '/history' },
    { id: 'settings', icon: FiSettings, label: 'Settings', path: '/settings' }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-lg border-t border-gray-200/50 px-4 py-2">
      <div className="flex justify-around items-center">
        {navItems.map((item) => (
          <motion.button
            key={item.id}
            onClick={() => navigate(item.path)}
            className={`flex flex-col items-center py-2 px-4 rounded-xl transition-colors ${
              currentScreen === item.id 
                ? 'text-blue-600 bg-blue-50' 
                : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <SafeIcon 
              icon={item.icon} 
              className={`text-xl mb-1 ${
                currentScreen === item.id ? 'text-blue-600' : 'text-gray-600'
              }`} 
            />
            <span className="text-xs font-medium">{item.label}</span>
          </motion.button>
        ))}
      </div>
    </div>
  );
};

export default BottomNavigation;