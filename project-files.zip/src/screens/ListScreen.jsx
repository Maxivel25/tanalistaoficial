import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useParams, useNavigate } from 'react-router-dom';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import AddItemModal from '../components/AddItemModal';
import EditItemModal from '../components/EditItemModal';

const { FiArrowLeft, FiPlus, FiEdit3, FiTrash2, FiCheck, FiPackage } = FiIcons;

const ListScreen = ({ lists, onUpdateList }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [list, setList] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingItem, setEditingItem] = useState(null);

  useEffect(() => {
    const currentList = lists.find(l => l.id === id);
    if (currentList) {
      setList(currentList);
    } else {
      navigate('/');
    }
  }, [id, lists, navigate]);

  if (!list) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
        <div className="text-white text-center">
          <div className="loading text-4xl mb-4">📦</div>
          <p>Loading list...</p>
        </div>
      </div>
    );
  }

  const addItem = (name, quantity) => {
    const newItem = {
      id: Date.now().toString(),
      name,
      quantity: quantity || '',
      purchased: false,
      addedAt: new Date().toISOString()
    };

    const updatedList = {
      ...list,
      items: [...list.items, newItem]
    };

    setList(updatedList);
    onUpdateList(list.id, updatedList);
    setShowAddModal(false);
  };

  const editItem = (itemId, name, quantity) => {
    const updatedList = {
      ...list,
      items: list.items.map(item =>
        item.id === itemId 
          ? { ...item, name, quantity: quantity || '' }
          : item
      )
    };

    setList(updatedList);
    onUpdateList(list.id, updatedList);
    setEditingItem(null);
  };

  const deleteItem = (itemId) => {
    const updatedList = {
      ...list,
      items: list.items.filter(item => item.id !== itemId)
    };

    setList(updatedList);
    onUpdateList(list.id, updatedList);
  };

  const togglePurchased = (itemId) => {
    const updatedList = {
      ...list,
      items: list.items.map(item =>
        item.id === itemId 
          ? { ...item, purchased: !item.purchased }
          : item
      )
    };

    setList(updatedList);
    onUpdateList(list.id, updatedList);
  };

  const pendingItems = list.items.filter(item => !item.purchased);
  const purchasedItems = list.items.filter(item => item.purchased);

  return (
    <motion.div 
      className="min-h-screen bg-gradient-to-br from-blue-500 to-purple-600 pb-6"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
    >
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-lg border-b border-white/20 sticky top-0 z-10">
        <div className="px-4 py-4">
          <div className="flex items-center space-x-4">
            <motion.button
              onClick={() => navigate('/')}
              className="p-2 text-white hover:bg-white/20 rounded-xl"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <SafeIcon icon={FiArrowLeft} className="text-xl" />
            </motion.button>
            <div className="flex-1">
              <h1 className="text-xl font-bold text-white">{list.name}</h1>
              <p className="text-white/80 text-sm">
                {list.items.length} items • {purchasedItems.length} completed
              </p>
            </div>
            <motion.button
              onClick={() => setShowAddModal(true)}
              className="bg-white/20 text-white p-2 rounded-xl"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <SafeIcon icon={FiPlus} className="text-xl" />
            </motion.button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 py-6">
        {list.items.length === 0 ? (
          <motion.div 
            className="text-center py-12"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
          >
            <SafeIcon icon={FiPackage} className="text-6xl text-white/60 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">Empty list</h3>
            <p className="text-white/80 mb-6">Add your first item to get started</p>
            <motion.button
              onClick={() => setShowAddModal(true)}
              className="bg-white text-blue-600 px-6 py-3 rounded-full font-semibold shadow-lg"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Add First Item
            </motion.button>
          </motion.div>
        ) : (
          <div className="space-y-6">
            {/* Pending Items */}
            {pendingItems.length > 0 && (
              <div>
                <h2 className="text-white font-semibold mb-3 text-lg">To Buy</h2>
                <div className="space-y-3">
                  <AnimatePresence>
                    {pendingItems.map((item, index) => (
                      <motion.div
                        key={item.id}
                        className="bg-white/90 backdrop-blur-lg rounded-2xl p-4 shadow-lg border border-white/20"
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: -20, opacity: 0 }}
                        transition={{ delay: index * 0.05 }}
                        layout
                      >
                        <div className="flex items-center space-x-3">
                          <motion.button
                            onClick={() => togglePurchased(item.id)}
                            className="w-6 h-6 border-2 border-gray-300 rounded-full flex items-center justify-center"
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                          >
                            <SafeIcon icon={FiCheck} className="text-transparent" />
                          </motion.button>
                          
                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-800">{item.name}</h3>
                            {item.quantity && (
                              <p className="text-gray-600 text-sm">Qty: {item.quantity}</p>
                            )}
                          </div>
                          
                          <div className="flex space-x-2">
                            <motion.button
                              onClick={() => setEditingItem(item)}
                              className="p-2 text-blue-600 hover:bg-blue-50 rounded-xl"
                              whileHover={{ scale: 1.1 }}
                              whileTap={{ scale: 0.9 }}
                            >
                              <SafeIcon icon={FiEdit3} className="text-sm" />
                            </motion.button>
                            <motion.button
                              onClick={() => deleteItem(item.id)}
                              className="p-2 text-red-500 hover:bg-red-50 rounded-xl"
                              whileHover={{ scale: 1.1 }}
                              whileTap={{ scale: 0.9 }}
                            >
                              <SafeIcon icon={FiTrash2} className="text-sm" />
                            </motion.button>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </div>
            )}

            {/* Purchased Items */}
            {purchasedItems.length > 0 && (
              <div>
                <h2 className="text-white/80 font-semibold mb-3 text-lg">Completed</h2>
                <div className="space-y-3">
                  <AnimatePresence>
                    {purchasedItems.map((item, index) => (
                      <motion.div
                        key={item.id}
                        className="bg-white/60 backdrop-blur-lg rounded-2xl p-4 shadow-lg border border-white/20"
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: -20, opacity: 0 }}
                        transition={{ delay: index * 0.05 }}
                        layout
                      >
                        <div className="flex items-center space-x-3">
                          <motion.button
                            onClick={() => togglePurchased(item.id)}
                            className="w-6 h-6 bg-green-500 border-2 border-green-500 rounded-full flex items-center justify-center"
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                          >
                            <SafeIcon icon={FiCheck} className="text-white text-xs" />
                          </motion.button>
                          
                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-600 line-through">{item.name}</h3>
                            {item.quantity && (
                              <p className="text-gray-500 text-sm line-through">Qty: {item.quantity}</p>
                            )}
                          </div>
                          
                          <motion.button
                            onClick={() => deleteItem(item.id)}
                            className="p-2 text-red-400 hover:bg-red-50 rounded-xl"
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                          >
                            <SafeIcon icon={FiTrash2} className="text-sm" />
                          </motion.button>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Floating Add Button */}
      <motion.button
        onClick={() => setShowAddModal(true)}
        className="fixed bottom-6 right-4 bg-white text-blue-600 p-4 rounded-full shadow-2xl border-2 border-blue-100"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.3, type: "spring" }}
      >
        <SafeIcon icon={FiPlus} className="text-2xl" />
      </motion.button>

      {/* Modals */}
      <AddItemModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSubmit={addItem}
      />

      <EditItemModal
        isOpen={!!editingItem}
        item={editingItem}
        onClose={() => setEditingItem(null)}
        onSubmit={editItem}
      />
    </motion.div>
  );
};

export default ListScreen;